export interface Persona {
  nombre: string;
  telefono: string;
  email: string;
}
